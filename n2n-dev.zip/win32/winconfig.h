/* winconfig.h.  Win32 replacement for file generated from config.h.in by configure.  */

/* OS name */
#ifndef PACKAGE_OSNAME
#define PACKAGE_OSNAME "windows"
#endif

/* Define to the version of this package. */
#ifndef PACKAGE_VERSION
#define PACKAGE_VERSION N2N_VERSION
#endif
